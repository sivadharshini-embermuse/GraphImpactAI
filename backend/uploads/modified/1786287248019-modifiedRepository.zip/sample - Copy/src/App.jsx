import { useState } from 'react';

const buttons = [
  '7', '8', '9', '/',
  '4', '5', '6', '*',
  '1', '2', '3', '-',
  '0', '.', '=', '+'
];

const isOperator = (value) => ['+', '-', '*', '/'].includes(value);
const endsWithOperator = (value) => /[+\-*/]$/.test(value);

function App() {
  const [display, setDisplay] = useState('0');
  const [overwrite, setOverwrite] = useState(true);

  const evaluateExpression = (expression) => {
    try {
      const result = eval(expression);
      return String(result);
    } catch {
      return 'Error';
    }
  };

  const deleteLast = () => {
    setDisplay((current) => {
      if (current === 'Error' || current.length === 1) {
        setOverwrite(true);
        return '0';
      }
      const next = current.slice(0, -1);
      return next === '' ? '0' : next;
    });
    setOverwrite(false);
  };

  const handleClick = (value) => {
    if (value === 'DEL') {
      deleteLast();
      return;
    }

    if (value === '=') {
      setDisplay((current) => evaluateExpression(current));
      setOverwrite(true);
      return;
    }

    if (isOperator(value)) {
      setDisplay((current) => {
        if (current === 'Error') {
          return '0' + value;
        }
        if (endsWithOperator(current)) {
          return current.slice(0, -1) + value;
        }
        return current + value;
      });
      setOverwrite(false);
      return;
    }

    setDisplay((current) => {
      if (current === 'Error' || overwrite || current === '0') {
        if (value === '.') {
          setOverwrite(true);
          return '0.';
        }
        setOverwrite(false);
        return value;
      }

      if (value === '.' && current.includes('.')) {
        return current;
      }

      return current + value;
    });
  };

  const clear = () => {
    setDisplay('0');
    setOverwrite(true);
  };

  return (
    <div className="calculator-page">
      <div className="calculator">
        <div className="screen">{display}</div>
        <button className="span-two delete" onClick={deleteLast}>DEL</button>
        <button className="span-two" onClick={clear}>C</button>
        {buttons.map((button) => (
          <button
            key={button}
            className={button === '=' ? 'equal' : ''}
            onClick={() => handleClick(button)}
          >
            {button}
          </button>
        ))}
      </div>
    </div>
  );
}

export default App;
