import { useState } from 'react';

const buttons = [
  '7', '8', '9', '/',
  '4', '5', '6', '*',
  '1', '2', '3', '-',
  '0', '.', '=', '+'
];

function App() {
  const [display, setDisplay] = useState('0');
  const [overwrite, setOverwrite] = useState(true);

  const handleClick = (value) => {
    if (value === '=') {
      try {
        const result = eval(display.replace(/×/g, '*').replace(/÷/g, '/'));
        setDisplay(String(result));
      } catch {
        setDisplay('Error');
      }
      setOverwrite(true);
      return;
    }

    if (overwrite) {
      if (value === '+' || value === '-' || value === '*' || value === '/') {
        setDisplay(display + value);
        setOverwrite(false);
      } else {
        setDisplay(value === '.' ? '0.' : value);
        setOverwrite(value === '.');
      }
      return;
    }

    if (value === '.' && display.includes('.')) {
      return;
    }

    setDisplay((current) => (current === '0' ? value : current + value));
  };

  const clear = () => {
    setDisplay('0');
    setOverwrite(true);
  };

  return (
    <div className="calculator-page">
      <div className="calculator">
        <div className="screen">{display}</div>
        <button className="span-two" onClick={clear}>C</button>
        {buttons.map((button) => (
          <button
            key={button}
            className={button === '=' ? 'equal' : ''}
            onClick={() => handleClick(button)}
          >
            {button}
          </button>
        ))}
      </div>
    </div>
  );
}

export default App;
